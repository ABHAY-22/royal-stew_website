

export const logo="./logo512.png"